const AWS = require("aws-sdk");
const util = require('util');

const client = new AWS.Location({ region: "eu-west-1" });

// Promisify the functions in order to be able to wait for them
const listDevicePositionsPromisified = util.promisify(client.listDevicePositions.bind(client))
const getDevicePositionHistoryPromisified = util.promisify(client.getDevicePositionHistory.bind(client))
const getDevicePositionPromisified = util.promisify(client.getDevicePosition.bind(client))

exports.handler = async (event) => {
    
    // Add CORS headers
    let response = {
        "isBase64Encoded": false,
        "headers": {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*",
            "Access-Control-Allow-Methods" : "*",
            "Access-Control-Allow-Credentials" : "true"
        }
    }
    
    let failed = false
    
    // The Lambda supports 3 typers of queries, listing all the devies in a tracker, getting the history of a device and getting the position of a single device
    try {
        if (event.queryStringParameters.type === "list") {
            const data = await listDevicePositionsPromisified({TrackerName: event.queryStringParameters.trackername})
            response["statusCode"] = 200
            response["body"] = JSON.stringify(data)
        } else if (event.queryStringParameters.type === "history") {
            console.log(event.queryStringParameters.trackername, event.queryStringParameters.deviceid)
            const data = await getDevicePositionHistoryPromisified({DeviceId: event.queryStringParameters.deviceid, TrackerName: event.queryStringParameters.trackername, StartTimeInclusive: new Date || 'Wed Dec 31 1969 16:00:00 GMT-0800 (PST)' || 123456789})
            response["statusCode"] = 200
            response["body"] = JSON.stringify(data)
        } else if (event.queryStringParameters.type === "device") {
            const data = await getDevicePositionPromisified({TrackerName: event.queryStringParameters.trackername, DeviceId: event.queryStringParameters.deviceid})
            response["statusCode"] = 200
            response["body"] = JSON.stringify(data)
        } else {
            failed = true
        }
    } catch(err) {
        failed = true
    }
    
    if (failed) {
        response["statusCode"] = 200
        response["body"] = "An error occurred"
    }

    return response;
};
